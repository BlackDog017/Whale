package com.yvjing.second_level2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<Student> studentList=new ArrayList<Student>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initStudents();
        ListView listView=(ListView)findViewById(R.id.list_view);
        StudentAdapter adapter = new StudentAdapter(MainActivity.this, R.layout.list_item, studentList);
        listView.setAdapter(adapter);
    }
    private void initStudents(){
    for(int i=0;i<10; i++) {
        Student student1 = new Student("第" + (i*3 + 1) + "个学生", "大一");
        Student student2 = new Student("第" + (i*3 + 2) + "个学生",  "大一");
        Student student3 = new Student("第" + (i*3 + 3) + "个学生",  "大一");
        Student student4 = new Student("第" + (i*3 + 4) + "个学生",  "大一");
        studentList.add(student1);
        studentList.add(student2);
        studentList.add(student3);
        studentList.add(student4);
    }

    }}

